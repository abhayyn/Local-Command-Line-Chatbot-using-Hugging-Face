#  Local CLI Chatbot using Hugging Face

## Overview
This is a local command-line chatbot built using a Hugging Face model like DialoGPT-small. It maintains short-term memory for coherent multi-turn conversation.

## Setup Instructions

1. Clone the repo or unzip the folder.
2. Install dependencies:
